moviepy.audio.fx.all.multiply_stereo_volume
===========================================

.. currentmodule:: moviepy.audio.fx.all

.. autofunction:: multiply_stereo_volume