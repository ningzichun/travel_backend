moviepy.audio.fx.all.multiply_volume
====================================

.. currentmodule:: moviepy.audio.fx.all

.. autofunction:: multiply_volume