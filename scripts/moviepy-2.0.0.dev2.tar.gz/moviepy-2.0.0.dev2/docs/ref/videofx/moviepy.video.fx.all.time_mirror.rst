moviepy.video.fx.all.time_mirror
================================

.. currentmodule:: moviepy.video.fx.all

.. autofunction:: time_mirror