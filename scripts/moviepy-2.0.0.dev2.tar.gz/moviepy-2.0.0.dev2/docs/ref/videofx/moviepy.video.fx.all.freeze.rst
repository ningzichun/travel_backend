moviepy.video.fx.all.freeze
===========================

.. currentmodule:: moviepy.video.fx.all

.. autofunction:: freeze