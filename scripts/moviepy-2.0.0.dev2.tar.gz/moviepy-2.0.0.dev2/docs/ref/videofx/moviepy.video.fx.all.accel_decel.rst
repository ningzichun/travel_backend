moviepy\.video\.fx\.all\.accel\_decel
=====================================

.. currentmodule:: moviepy.video.fx.all

.. autofunction:: accel_decel