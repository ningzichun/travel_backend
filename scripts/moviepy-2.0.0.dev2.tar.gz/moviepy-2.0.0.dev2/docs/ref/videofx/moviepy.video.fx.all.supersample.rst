moviepy\.video\.fx\.all\.supersample
====================================

.. currentmodule:: moviepy.video.fx.all

.. autofunction:: supersample