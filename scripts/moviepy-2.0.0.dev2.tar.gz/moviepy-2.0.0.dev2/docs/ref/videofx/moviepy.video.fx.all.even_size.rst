moviepy\.video\.fx\.all\.even\_size
===================================

.. currentmodule:: moviepy.video.fx.all

.. autofunction:: even_size