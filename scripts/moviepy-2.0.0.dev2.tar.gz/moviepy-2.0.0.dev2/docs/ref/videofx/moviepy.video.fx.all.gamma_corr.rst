moviepy.video.fx.all.gamma_corr
===============================

.. currentmodule:: moviepy.video.fx.all

.. autofunction:: gamma_corr