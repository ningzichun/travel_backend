moviepy.video.fx.all.multiply_color
===================================

.. currentmodule:: moviepy.video.fx.all

.. autofunction:: multiply_color