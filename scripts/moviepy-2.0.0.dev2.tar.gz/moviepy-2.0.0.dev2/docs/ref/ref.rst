.. _reference_manual:


Reference Manual
================

The documentation may be a little messy for the moment, it will get better with time.
If you want to hack into the code or locate a particular function, read :ref:`codeorganization` .


.. toctree::
   :maxdepth: 3

   Clip
   VideoClip/VideoClip
   AudioClip
   videofx
   audiofx
   videotools
   audiotools
   ffmpeg
   decorators
   code_origanization
