************
Clip
************

:class:`Clip`
==========================

.. autoclass:: moviepy.Clip.Clip
   :members:
   :inherited-members:
   :show-inheritance:
