======================
A simple music video
======================

.. raw:: html

        <div style="position: relative; padding-bottom: 56.25%; padding-top: 30px; margin-bottom:30px; height: 0; overflow: hidden; margin-left: 5%;"><iframe type="text/html" src="https://www.youtube.com/embed/AqGZ4JFkQTU" frameborder="0" style="position: absolute; top: 0; bottom: 10; width: 90%; height: 100%;" allowfullscreen></iframe></div>

This is an example, with no sound (lame for a music video), soon to be
replaced with a real music video example (the code will be 99% the same).
The philosophy of MoviePy is that for each new music video I will make,
I will just have to copy/paste this code, and modify a few lines.

.. literalinclude:: ../../examples/ukulele_concerto.py
